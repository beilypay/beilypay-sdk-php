<?php
require_once __DIR__ . "/beilypay/beilypay.inc.php";

use beilypay\Beilypay;

// 创建一个 Beilypay 对象，传入 APPID, merchantId, appSecure, apiHost
$b = new Beilypay("1183601355", 3, "8c62bd95169ba8818c676a6f2025b8e5", "http://dev.beilypay.com");

//
// 创建代收订单
//
try {
    $orderNum = md5(time() . rand(0, 999999));
    $data = $b->createPayment($orderNum, 111, "http://www.baidu.com/", "http://www.baidu.com/");
    echo "OK createPayment {$data->orderNo}\n";
} catch(Exception $e) { 
    echo(sprintf("ERROR createPayment %s\n", $e->getMessage()));
}

//
// 查询代收订单
//
try {
    $orderNo = $data->orderNo;
    $order = $b->queryPayment($orderNo);
    echo "OK queryPayment {$data->orderNo}\n";
}catch(Exception $e) { 
    echo(sprintf("ERROR queryPayment %s\n", $e->getMessage()));
}


//
// 创建代付订单
//
try {
    $orderNum = md5(time() . rand(0, 999999));
    $data = $b->createTrans($orderNum, 123, "http://www.baidu.com/", "Card", "account", "owner", "bankcode", "ifsc");
    echo "OK createTrans {$data->orderNo}\n";
}catch(Exception $e) { 
    echo(sprintf("ERROR createTrans %s\n", $e->getMessage()));
}

//
// 查询代付订单
//
try {
    $orderNo = $data->orderNo;
    $order = $b->queryTrans($orderNo);
    echo "OK queryTrans {$data->orderNo}\n";
}catch(Exception $e) {  
    echo(sprintf("ERROR queryTrans %s\n", $e->getMessage()));
}


// 
// 参数签名校验匹配
//
$request = array(
    "abc" => "a123",
    "acd" => 1234,
);
$request["sign"] = $b->sign($request);
echo("sign = {$request['sign']}\n");
$ok = $b->verfy($request);
var_dump($ok);