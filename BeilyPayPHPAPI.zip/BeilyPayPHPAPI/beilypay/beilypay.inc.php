<?php

require_once __DIR__ . "/../httpclient-master/httpclient.inc.php";
require_once __DIR__ . "/Beilypay.php";
require_once __DIR__ . "/Order.php";